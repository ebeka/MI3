<?php
session_start();


$Titel = "";
$Duur = "";
$Ingredienten = "";
$Bereiding = "";
$Category = "";
$errors = array(); 



$db = mysqli_connect('localhost', 'id8536747_userrecepten', 'abc123', 'id8536747_dbrecepten');


if (isset($_POST['save_rec'])) {
  // receive all input values from the form
  $Titel = mysqli_real_escape_string($db, $_POST['Titel']);
  $Duur = mysqli_real_escape_string($db, $_POST['Duur']);
  $Ingredienten = mysqli_real_escape_string($db, $_POST['Ingredienten']);
  $Bereiding = mysqli_real_escape_string($db, $_POST['Bereiding']);
  $Category = mysqli_real_escape_string($db,  $_POST['Category']); 
  $target = "WebsiteBedrijf/images/".basename($Image);
  $Image = $_FILES['image']['name'];

  	

  	$query = "INSERT INTO recept (titel, category, duur, ingredienten, bereiding, image) 
  			  VALUES('$Titel', '$Category','$Duur', '$Ingredienten', '$Bereiding', '$Image')";
  	mysqli_query($db, $query);
	
	if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
  		$msg = "Image uploaded successfully";
  	}else{
  		$msg = "Failed to upload image";
  	}
	
  	header('location: ../index.php');
  }
?>