<?php 
  session_start(); 

  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: ../html/Navigatie2.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: ../html/Navigatie2.php");
  }
?>

<!DOCTYPE html>
<HTML>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact</title>
    <link href="../css/Css.css" rel="stylesheet" />
    <link rel="shortcut icon" type="image/png" href="../images/Tlogo.png">
</head>

<body>

    <script src="../Js/myScript.js"></script>

    <div id="header">
        <p style="text-align:center"><img src="../images/Tlogo.png" alt="logo" style="width: 10%; min-width: 100px; height:20%;"></p>
    </div>

    <nav>

        <div id="mySidenav" class="sidenav">
            <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
            <a href="../index.php">Home</a>
            <a href="../html/Navigatie2.php">Recept Maken</a>
			<a href="../html/Navigatie8.php">Zoeken</a>
            <a href="../html/Navigatie3.php">Voorgerecht</a>
            <a href="../html/Navigatie4.php">Gerecht</a>
			<a href="../html/Navigatie5.php">Dessert</a>
            <a href="../html/Navigatie6.php">Contact</a>
        </div>
        <span class="menubalk" style="font-size:30px;cursor:pointer; color:white" onclick="openNav()">&#9776; Menu</span>

        <img src="../images/long2.jpg" alt="huur" style=" border-radius: 4px;  width:100%;">
    </nav>


    <article>
        <h1>Contact Gegevens</h1>

        <p>Brand Whitlocklaan 14 - BE 1200 Brussel <br>+32 470 20 9000 / +32 2 7 20 9000 <br><br>Lekker-Eten@EzFood.eu</p>
        <br>

       

    </article>

    <aside>

        <h3>Contacteer ons:</h3>

        <form action="mailto:someone@example.com" method="post" enctype="text/plain">
            <label for="fname">Volledige Naam</label>
            <input type="text" id="fname" name="volledige naam" placeholder="Uw Volledige Naam">

            <label for="email">Email</label>
            <input type="text" id="email" name="email" placeholder="Uw Email">

            <label for="telnr">Telefoon Nummer</label>
            <input type="text" id="telnr" name="telefoonnr" placeholder="Uw Telefoon Nummer">

            <label for="message">Bericht</label>
            <input type="text" id="message" name="message" placeholder="Bericht">

            <input type="submit" value="Send">
        </form>
    </aside>

    <div id="map"></div>

    <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCmPebpvr1_ONsKMwRqarK9YXnhRodPQug&callback=initMap">


    </script>

    <footer>
        EzFood
    </footer>


</body>

</HTML>
