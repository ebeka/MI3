<?php include('../../server2.php') ?>
<!DOCTYPE html>
<HTML>

<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link href="../css/Css.css" rel="stylesheet" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" type="image/png" href="../images/Tlogo.png">
</head>

<body>

    <script src="../Js/myScript.js"></script>

    <div id="header">
        <p style="text-align:center"><img src="../images/Tlogo.png" alt="logo" style="width: 10%; min-width: 100px; height:20%;"></p>
    </div>

    <nav>

        <div id="mySidenav" class="sidenav">
            <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
            <a href="../index.php">Home</a>
            <a href="../html/Navigatie2.php">Recept Maken</a>
			<a href="../html/Navigatie8.php">Zoeken</a>
            <a href="../html/Navigatie3.php">Voorgerecht</a>
            <a href="../html/Navigatie4.php">Gerecht</a>
			<a href="../html/Navigatie5.php">Dessert</a>
            <a href="../html/Navigatie6.php">Contact</a>
        </div>
        <span class="menubalk" style="font-size:30px;cursor:pointer; color:white" onclick="openNav()">&#9776; Menu</span>

        <img src="../images/long2.jpg" alt="huur" style=" border-radius: 4px;  width:100%;">
    </nav>



  	
 
	 
  <form method="post" action="Navigatie2.2.php">
  	<?php include('../../errors.php'); ?>
	<h2>Login</h2>
	
  	<div class="input-group">
  		<label>Username</label>
  		<input type="text" name="username" >
  	</div>
  	<div class="input-group">
  		<label>Password</label>
  		<input type="password" name="password">
  	</div>
  	<div class="input-group">
  		<button type="submit" class="btn" name="login_user">Login</button>
  	</div>
  	<p>
  		Not yet a member? <a href="Navigatie2.php">Sign up</a>
  	</p>
  </form>

    
    <br>
    <footer>
        EzFood
    </footer>


</body>

</HTML>
