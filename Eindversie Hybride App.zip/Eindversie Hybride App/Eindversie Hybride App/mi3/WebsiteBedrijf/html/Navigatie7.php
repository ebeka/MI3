<?php 
  session_start(); 

  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: ../html/Navigatie2.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: ../html/Navigatie2.php");
  }
?>

<?php 

$Titel = "";
$Duur = "";
$Ingredienten = "";
$Bereiding = "";
$Category = "";
$errors = array(); 



$db = mysqli_connect('localhost', 'id8536747_userrecepten', 'abc123', 'id8536747_dbrecepten');


if (isset($_POST['save_rec'])) {
  // receive all input values from the form
  $Titel = mysqli_real_escape_string($db, $_POST['Titel']);
  $Duur = mysqli_real_escape_string($db, $_POST['Duur']);
  $Ingredienten = mysqli_real_escape_string($db, $_POST['Ingredienten']);
  $Bereiding = mysqli_real_escape_string($db, $_POST['Bereiding']);
  $Category = mysqli_real_escape_string($db,  $_POST['Category']); 

  $Image = $_FILES['image']['name'];
  $target = "../images/".basename($Image);
  	

  	$query = "INSERT INTO recept (titel, category, duur, ingredienten, bereiding, image) 
  			  VALUES('$Titel', '$Category','$Duur', '$Ingredienten', '$Bereiding', '$Image')";
  	mysqli_query($db, $query);
	
	if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
  		$msg = "Image uploaded successfully";
  	}else{
  		$msg = "Failed to upload image";
  	}

  }
  ?>



<!DOCTYPE html>
<HTML>

<head>
    <meta charset="UTF-8">
    <title>Recept</title>
    <link href="../css/Css.css" rel="stylesheet" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" type="image/png" href="../images/Tlogo.png">
</head>

<body>

    <script src="../Js/myScript.js"></script>

    <div id="header">
        <p style="text-align:center"><img src="../images/Tlogo.png" alt="logo" style="width: 10%; min-width: 100px; height:20%;"></p>
    </div>

    <nav>

        <div id="mySidenav" class="sidenav">
            <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
            <a href="../index.php">Home</a>
            <a href="../html/Navigatie2.php">Recept Maken</a>
			<a href="../html/Navigatie8.php">Zoeken</a>
            <a href="../html/Navigatie3.php">Voorgerecht</a>
            <a href="../html/Navigatie4.php">Gerecht</a>
			<a href="../html/Navigatie5.php">Dessert</a>
            <a href="../html/Navigatie6.php">Contact</a>
        </div>
        <span class="menubalk" style="font-size:30px;cursor:pointer; color:white" onclick="openNav()">&#9776; Menu</span>

        <img src="../images/long2.jpg" alt="huur" style=" border-radius: 4px;  width:100%;">
    </nav>



<form method="post" action="Navigatie7.php" id="usrform" enctype="multipart/form-data">
	<input type="hidden" name="size" value="1000000">
	<h1> Recept Schijven </h1>
  	<div class="input-group">
  	  <label>Titel Recept</label>
  	  <input type="text" name="Titel" >
  	</div>
	<div class="input-group">
		<select name="Category" style=" width:93%;">
			<option value="Voorgerecht">Voorgerecht</option>
			<option value="Gerecht">Gerecht</option>
			<option value="Dessert">Dessert</option>
		</select>
	</div>
  	<div class="input-group">
  	  <label>Duur Recept</label>
  	  <input type="text" name="Duur">
  	</div>
  	<div class="input-group">
  	  <label>Ingredienten</label>
	  <textarea rows="4" cols="50" name="Ingredienten" form="usrform" style=" width:93%;"></textarea>
  	</div>
  	<div class="input-group">
  	  <label>Bereiding</label>
	  <textarea rows="4" cols="50" name="Bereiding" form="usrform" style=" width:93%;"></textarea>
  	</div>
	<div class="input-group">
	  <label>Afbeelding</label>
  	  <input type="file" name="image">
  	</div>
  	<div class="input-group">
  	  <button type="submit" class="btn" name="save_rec">Upload</button>
  	</div>
  	
  </form>

    
    <br>
    <footer>
        EzFood
    </footer>


</body>

</HTML>
