<?php 
  session_start(); 

  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: ../html/Navigatie2.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: ../html/Navigatie2.php");
  }
?>

<?php   

$DReceptId = "";
$Dgebruiker = "";
$DCommentaar = "";

if (isset($_POST['save_rec'])) {
  
  $db3 = mysqli_connect('localhost', 'id8536747_userrecepten', 'abc123', 'id8536747_dbrecepten');	
  
  $DReceptId = mysqli_real_escape_string($db3, $_POST['Greceptid']);
  $DGebruiker = mysqli_real_escape_string($db3, $_POST['Ggebruiker']);
  $DCommentaar = mysqli_real_escape_string($db3, $_POST['Gcommentaar']);
   

  	$query3 = "INSERT INTO commentaar (receptid, commentaar, gebruiker) 
  			  VALUES('$DReceptId', '$DCommentaar','$DGebruiker')";
  	mysqli_query($db3, $query3);


  }
?> 

<!DOCTYPE html>
<HTML>

<head>
    <meta charset="UTF-8">
    <title>Gerecht</title>
    <link href="../css/Css.css" rel="stylesheet" />
    <link rel="shortcut icon" type="image/png" href="../images/Tlogo.png">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	
	<script>
	function doSomething(elem) {
	
	var DivId = document.getElementById(elem);
	if (DivId.style.display === "none") {
    DivId.style.display = "block";
	} else {
    DivId.style.display = "none";
	}
	}

	function doSomething2(Rid, Usrn) {
	
   document.getElementById("formReceptId").value = Rid;
   document.getElementById("formGebruiker").value = Usrn;
	}
	
	function doSomething3(elem2) {
	
	var DivId2 = document.getElementById(elem2);
	if (DivId2.style.display === "none") {
    DivId2.style.display = "block";
	} else {
    DivId2.style.display = "none";
	}
	}
	</script>
	
</head>


<body>

    <script src="../Js/myScript.js"></script>

    <div id="header">
            <p style="text-align:center"><img src="../images/Tlogo.png" alt="logo" style="width: 10%; min-width: 100px; height:20%;"></p>
    </div>

    <nav>

        <div id="mySidenav" class="sidenav">
            <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
            <a href="../index.php">Home</a>
            <a href="../html/Navigatie2.php">Recept Maken</a>
			<a href="../html/Navigatie8.php">Zoeken</a>
            <a href="../html/Navigatie3.php">Voorgerecht</a>
            <a href="../html/Navigatie4.php">Gerecht</a>
			<a href="../html/Navigatie5.php">Dessert</a>
            <a href="../html/Navigatie6.php">Contact</a>
        </div>
        <span class="menubalk" style="font-size:30px;cursor:pointer; color:white" onclick="openNav()">&#9776; Menu</span>

        <img src="../images/long2.jpg" alt="huur" style=" border-radius: 4px;  width:100%;">
    </nav>
	
	
	<div class="artikelen">
		<h1 style="text-align:center; font-weight:bold;"> Gerechten: </h1>
		
		<?php
		$db = mysqli_connect('localhost', 'id8536747_userrecepten', 'abc123', 'id8536747_dbrecepten');	
		$sql = "SELECT * FROM recept where category = 'Gerecht'";
		$result = mysqli_query($db, $sql);
		
		while ($row = mysqli_fetch_array($result))
		{
			echo "<div class='artikel'>";
			echo "<h1>".$row['titel']."</h1>";
			echo "<b><p>Tijd: </p></b>";
			echo "<p>".$row['duur']."</p>";
			echo "<img style='width:279px;' src='../images/".$row['image']."' >";
			echo "<div  id='b".$row['id']."' style='display:none;' >";
			echo "<b><p>Ingredienten: </p></b>";
			echo "<p>".$row['ingredienten']."</p>";
			echo "<b><p>Bereiding: </p></b>";
			echo "<p>".$row['bereiding']."</p>";
			
			
			$sql2 = "SELECT * FROM commentaar where receptid = '".$row['id']."'";
			$result2 = mysqli_query($db, $sql2);
			echo "<div  id='c".$row['id']."' style='display:none;' >";
			echo "<b><h3>Commentaar:</h2></b>";
			while ($row2 = mysqli_fetch_array($result2))
			{
					
				echo "<b><p>".$row2['gebruiker'].":</p></b>";
				echo "<p>".$row2['commentaar']."</p>";				
			
			}
			
			echo "<a href='#openModal'><button value='".$row['id']."' name='".$_SESSION['username']."' onclick='doSomething2(this.value,this.name)' >Geef Commentaar</button></a>";
			echo "</div>";			
			echo "<button  value='c".$row['id']."' onclick='doSomething(this.value)'>Toon/Verstop Commentaar</button>";
			echo "</div>";
			echo "<button  value='b".$row['id']."' onclick='doSomething3(this.value)'>Toon/Verstop Recept</button>";
			echo "</div>";
		}
		?>
			
			
    </div>

		

	<div id="openModal" class="modalDialog">
    <div>	<a href="#close" title="Close" class="close">X</a>
	
        <form method='post' action='Navigatie4.php' id='usrform' enctype='multipart/form-data'>
		<input type='hidden' name='size' value='1000000'>
		<h1> Commentaar Schijven </h1>
  	
		<div style='display:none;'  >
		<div class='input-group'>
		<input type='text' name='Greceptid' id='formReceptId' value='' >
		</div>
		<div class='input-group'>
		<input type='text' name='Ggebruiker' id='formGebruiker' value=''>
		</div>
		</div>
		<div class='input-group'>
		<label>Commentaar:</label>
		<textarea rows='4' cols='50'  name='Gcommentaar' form='usrform' style='width:93%;'></textarea>
		</div>
		<div class='input-group'>
		<button type='submit' class='btn' name='save_rec'>Verstuur Commentaar</button>
		</div>
  		</form>
    </div>
	</div>

    
    <br>
    <footer>
        EzFood
    </footer>


</body>

</HTML>


