<?php 
  session_start(); 

  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: html/Navigatie2.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: html/Navigatie2.php");
  }
?>

<!DOCTYPE html>
<HTML>

<head>
    <meta charset="UTF-8">
    <title>Home</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/Css.css" rel="stylesheet" />
    <link rel="shortcut icon" type="image/png" href="images/o.png">
</head>

<body>

    <script src="Js/myScript.js"></script>

    <div id="header">
        <p style="text-align:center"><img src="images/Tlogo.png" alt="logo" style="width: 10%; min-width: 100px; height:20%;"></p>
    </div>

    <nav>

        <div id="mySidenav" class="sidenav">
            <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
            <a href="index.php">Home</a>
            <a href="html/Navigatie7.php">Recept Maken</a>
			<a href="html/Navigatie8.php">Zoeken</a>
            <a href="html/Navigatie3.php">Voorgerecht</a>
            <a href="html/Navigatie4.php">Gerecht</a>
			<a href="html/Navigatie5.php">Dessert</a>
            <a href="html/Navigatie6.php">Contact</a>
        </div>
        <span class="menubalk" style="font-size:30px;cursor:pointer; color:white" onclick="openNav()">&#9776; Menu</span>

        <img src="images/long2.jpg" alt="huur" style=" border-radius: 4px;  width:100%;">
    </nav>
	
	<div class="content">
  	<!-- notification message -->
  	

    <!-- logged in user information -->
    <?php  if (isset($_SESSION['username'])) : ?>
    	<p>Welcome <strong><?php echo $_SESSION['username']; ?></strong></p>
    	<p> <a href="index.php?logout='1'" style="color: red;">Logout</a> </p>
    <?php endif ?>
	</div>

    <article>
        <h1>EzFood</h1>

        <p>Wij  zijn een groep studenten die geinteresserd zijn om lekkere gerechten te maken op een zo goedkoop mogelijk budget.</p>

        <p>Op EzFood kan je makkelekijk gerechten vinden die je met je studentenbudget kan klaarmaken.
		<br>Als je zelf ook ideeen hebt voor lekkere recepten dan kan je die altijd delen met ons voor andere studenten.</p>
        <br>
        <h2>We nodigen u vriendelijk uit om eens een kijkje te nemen in onze app.</h2>
		<br>
		
		<center><h2><a href="html/Navigatie3.php"><img border="0" alt="Voorgerecht" src="images/Voorgerecht.png" width="200" height="75"></a></h2></center>
		
		<center><h2><a href="html/Navigatie4.php"><img border="0" alt="Gerecht" src="images/Gerecht.png" width="200" height="75" ></a></h2></center>
		
		<center><h2><a href="html/Navigatie5.php"><img border="0" alt="Dessert" src="images/Dessert.png" width="200" height="75"></a></h2></center>

  
    </article>


   


    
    <footer>
        EzFood
    </footer>


</body>

</HTML>
