<?php
session_start();
 

$conn = mysqli_connect('localhost', 'id8536747_userrecepten', 'abc123', 'id8536747_dbrecepten');
$sql = "SELECT * FROM recept where category = 'Dessert'";
$result = mysqli_query($conn, $sql);

$data = array();
while($row = mysqli_fetch_assoc($result))
{
	$date[] = $row;
}

echo json_encode($data);
		
?> 