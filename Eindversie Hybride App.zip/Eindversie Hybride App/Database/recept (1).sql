-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Gegenereerd op: 23 jan 2019 om 12:44
-- Serverversie: 10.1.36-MariaDB
-- PHP-versie: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbrecepten`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `recept`
--

CREATE TABLE `recept` (
  `id` int(11) NOT NULL,
  `titel` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `duur` varchar(255) NOT NULL,
  `ingredienten` text NOT NULL,
  `bereiding` text NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `recept`
--

INSERT INTO `recept` (`id`, `titel`, `category`, `duur`, `ingredienten`, `bereiding`, `image`) VALUES
(28, 'Crumble met appel en blauwe bessen', 'Dessert', '30 min', '2 zoete appels250 grblauwe bessen1 elcitroensap3 elahornsiroop3 elhavermoutbloem1/2 klkaneelVoor de crumble:45 grhavermout50 grhavermoutbloem2 elamandelen, fijngehakt1 tlkaneel1 snuifjezout1 elpindakaas3 elgesmolten kokosolie3 elahornsiroop', 'Schil de appels, verwijder het klokhuis en snijd ze in blokjes. Neem een grote kom en meng daarin de blokjes appel, de blauwe bessen, het citroensap, de ahornsiroop, de havermoutbloem en de kaneel.\r\n\r\nMeng vervolgens in een andere kom alle ingrediÃ«nten voor de crumble.\r\n\r\nNeem een grote ovenschaal en verheel het appel-bessenmengsel over de bodem. Bedek het fruit vervolgens met de crumble. Plaats nu de schotel gedurende 25 minuten in een voorverwarmde oven van 180 graden.\r\n', 'applecrumble_89166_16x9.jpg'),
(30, 'Luchtig bananenbrood met chocolade', 'Dessert', '+1 uur', '250 grbloem1 tlbicarbonaat1 tlbakpoeder1/4 tlkaneel1/2 tlzout4 rijpe bananen70 grbruine suiker50 mlkoolzaadolie100 mlmelk1 tlvanille-extract100 grchocolate-chipsboter (om in te vetten)', 'Zeef alle droge ingrediÃ«nten in een grote kom. Pel de bananen, snijd de in stukjes en prak de stukjes fijn in een kom. Roer er vervolgens de bruine suiker, de koolzaadolie, de melk en het vanille-extract onder.\r\n\r\nMeng nu de droge ingrediÃ«nten onder het bananenmengsel en spatel er de chocolate chips onder.\r\n\r\nVet een bakblik in met een laagje boter en schep er vervolgens het beslag in. Plaats het bananenbrood nu gedurende 50 minuten Ã  1 uur in een voorverwarmde oven van 175 graden. ', '3046446846546843541.jpg'),
(31, 'CrÃ¨me brulÃ©e', 'Dessert', '+2 uur', '10 eigelen200 grsuiker3 dlvolle melk9 dlvolle room1 vanillestokRecept afdrukken', 'Roer de suiker onder de eigelen. Voeg hier de volle melk en de room aan toe. Schraap de zaadjes uit de vanillestok en voeg bij het mengsel. Laat een uurtje rusten in de koelkast.\r\n\r\nDoe het mengsel in vuurvaste schaaltjes en bak de crÃ¨me brulÃ©e af gedurende 1 uur en 15 minuten in een voorverwarmde oven van 95 graden. Haal ze uit de oven en laat ze afkoelen.\r\n\r\nBestrooi de crÃ¨me brulÃ©es met fijne suiker en karamelliseer de suiker met een brander. ', 'creme-brulee-french-custard-recipe-11.jpg'),
(32, 'Tiramisu', 'Dessert', '+1 uur', 'zeer sterke koffie6 elamaretto1 paklange vingerkoekjes (boudoirs)6 elwitte suiker4 eiwitten5 eierdooiers500 grmascarponecacaopoeder', 'Laat de koffie afkoelen en meng er de amaretto door. Dip de vingerkoekjes in het koffiemengsel en leg ze op de bodem van een rechthoekige schotel. \r\n\r\nDoe drie eetlepels suiker bij het eiwit en klop stijf.\r\n\r\nDoe drie eetlepels suiker bij de eidooiers en klop tot room. Roer de mascarpone door de eierdooierroom. \r\n\r\nSpatel voorzichtig het eiwit door het mengsel van eierdooiers en mascarpone. Je bekomt een mascarponeroom. Breng daarvan een laagje aan op de koekjes. \r\n\r\nHerhaal dit procedÃ©: leg een tweede laag vingerkoekjes en daarop een tweede laag room. \r\n\r\nLaat een nachtje rusten in de koelkast. \r\n\r\nSERVEREN:\r\n\r\nBestrooi de tiramisu net voor het serveren met flink wat cacaopoeder.', 'tiramisu13456453458.jpg'),
(33, 'Chocoladeroompap met petit beurre koekjes', 'Dessert', '+1 uur', '3 blaadjesgelatine0,5 literroom (vetgehalte >40%)200 grdonkere chocolade1 elsuiker12 petit beurre koekjesRecept afdrukkenLaat de gelatineblaadjes weken in koud water. \r\n\r\nDoe de room in een kookpot en voeg 1 eetlepel suiker toe. Zet de pot op het vuur en breng de room aan de kook. Roer vervolgens de chocolade onder de room en laat opnieuw even opkoken. Knijp het water uit de gelatineblaadjes en meng ze onder de chocoladeroom. \r\n\r\nNeem vier potjes of schaaltjes en leg op de bodem telkens een koekje. Giet er een laagje chocoladeroom op. Leg vervolgens opnieuw een koekje en giet er opnieuw chocoladeroom op. Herhaal tot alles opgebruikt is.', 'Laat de gelatineblaadjes weken in koud water. \r\n\r\nDoe de room in een kookpot en voeg 1 eetlepel suiker toe. Zet de pot op het vuur en breng de room aan de kook. Roer vervolgens de chocolade onder de room en laat opnieuw even opkoken. Knijp het water uit de gelatineblaadjes en meng ze onder de chocoladeroom. \r\n\r\nNeem vier potjes of schaaltjes en leg op de bodem telkens een koekje. Giet er een laagje chocoladeroom op. Leg vervolgens opnieuw een koekje en giet er opnieuw chocoladeroom op. Herhaal tot alles opgebruikt is.', 'Boekweit-chocolade-pap-skyr-arla.jpg'),
(34, 'Reefilet met bospaddenstoelen en portosaus', 'Gerecht', '30 - 60 min', 'wildbouillon\r\n\r\nÂ½ kg bospaddenstoelen\r\n\r\n600 g reefilet\r\n\r\n2 dl porto\r\n\r\n2 dl water\r\n\r\nboter\r\n\r\n2 tenen knoflook\r\n\r\n2 sjalotten\r\n\r\n2 dl room\r\n\r\n100 g spekblokjes', 'Haal de ree zeker een uur op voorhand uit de koelkast. Zo komt het vlees op kamertemperatuur. Smelt boter in een pan. Bak de ree eventjes aan beide kanten aan in de gesmolten boter. Kleur goed aan.\r\n\r\nBak de versneden teentjes look en de sjalot in een andere pan. Doe er de spekblokjes en de versneden bospaddenstoelen bij.\r\n\r\nHaal de ree uit de pan. Hou warm onder aluminiumfolie. Blus de pan met de porto en het water en voeg er een koffielepel wildbouillon aan toe. Laat het geheel even inkoken. Doe er nu nog een beetje room bij en laat nog even opkoken.\r\n\r\nServeer de ree met de champignons en de saus', 'Reefilet-met-bospaddenstoelen-en-portosaus-Piet-Huysentruyt-e1540478893165.jpg'),
(35, 'Ribbetjes met honing en gepofte aardappel met kruidenboter', 'Gerecht', '+90 min', '1,4 kg varkensribbetjes\r\n\r\n1 ui\r\n\r\n2 teentjes knoflook\r\n\r\n1 tl sambal oelek\r\n\r\n10 el vloeibare honing\r\n\r\n5 el witte wijnazijn\r\n\r\n5 el ketchup\r\n\r\n1 tl (gerookt) paprikapoeder\r\n\r\n1 tl currypoeder\r\n\r\nvers gemalen peper\r\n\r\neen snuifje zeezout\r\n\r\nvoor de gepofte aardappel met kruidenboter\r\n\r\n4 aardappelen (grote, vastkokend)\r\n\r\n100 g boter\r\n\r\n1 sjalot\r\n\r\nvers gemalen peper\r\n\r\neen snuifje grof zeezout\r\n\r\nsap en zeste van 1 citroen\r\n\r\neen handvol platte petserselie\r\n\r\nvoor de witte koolsalade\r\n\r\n1/4 witte kool\r\n\r\n1 komkommer\r\n\r\n1 bosje verse dille\r\n\r\n6 el chardonnay azijn\r\n\r\n6 el zonnebloemolie\r\n\r\n3 el Griekse yoghurt\r\n\r\nvers gemalen peper\r\n\r\neen snuifje zeezout', 'Maak de marinade: Schil de ui en snipper fijn. Schil de knoflook, pers uit en meng met de rest van de ingredienten.  \r\n\r\nMarineer de ribbetjes: Laat de ribbetjes minstens 2h marineren in de koelkast. (Je krijgt het beste resultaat als je ze een hele nacht laat marineren.)\r\n\r\n Bak de ribbetjes: Verwarm de oven voor op 150C. Verdeel de ribbetjes over een grill op de bakplaat en zet 2h in de oven.  \r\n\r\nMaak de gepofte aardappel: Schrob de aardappelen goed en stoom ze gaar.\r\n\r\nMaak de kruidenboter: Schil de sjalot en snipper fijn. Hak de kruiden en meng door de boter met de rest van de ingredienten. \r\n\r\nMaak de wittekoolsalade: Cutter de kool en komkommer en meng met de rest van de ingredienten. Breng op smaak met peper en zout.\r\n\r\nWerk af: Haal de ribbetjes uit de oven en verhoog de temperatuur van de oven naar 250C.  \r\n\r\nSnij de aardappelen doormidden en schep er de kruidenboter in. \r\n\r\nZet de ribbetjes 3-5 minuten in de oven tot ze mooi gekarameliseerd zijn.\r\n\r\nServeer de ribbetjes met de gepofte aardappel met kruidenboter en de witte koolsalade.', '3064846458753.jpg'),
(36, 'Spaghetti met tomatensaus en balletjes', 'Gerecht', '30 - 60 min', '300 g spaghetti\r\n\r\n500 g gehakt\r\n\r\nversgemalen peper\r\n\r\nzeezout\r\n\r\neen scheutje olijfolie\r\n\r\n1 teentje knoflook\r\n\r\n1 sjalot\r\n\r\nverse tijm\r\n\r\nverse rozemarijn\r\n\r\neen snuifje cayenneper\r\n\r\neen snuifje oregano\r\n\r\npassata\r\n\r\ngemalen Parmezaanse kaas\r\n', 'Kook de spaghetti gaar in gezouten water en giet af. \r\n\r\nMaak de balletjes: Kruid het gehakt met peper en zout.\r\n\r\nRol het gehakt tot balletjes en bak aan in olijfolie. \r\n\r\nPel en snipper de sjalot en knoflook en stoof aan in olijfolie. \r\n\r\nVoeg de tijm, rozemarijn, cayennepeper en oregano toe. \r\n\r\nDoe er de tomatensaus bij. \r\n\r\nBreng op smaak met peper en zout.\r\n\r\nMeng de spaghetti met de saus, balletjes en gemalen kaas. ', '1506456062-delish-spaghetti-meatballs.jpg'),
(37, 'Roodbaars uit de oven met venkel, wortel en komijn', 'Gerecht', '30 - 60 min', '16 krieltjes\r\n\r\n800 g wortelen\r\n\r\n1 venkel\r\n\r\nolijfolie\r\n\r\nversgemalen peper\r\n\r\nzeezout\r\n\r\ngemalen komijn\r\n\r\n4 stukken roodbaars\r\n\r\nlimoenzeste\r\n\r\nzwart sesamzaad', 'https://koken.vtm.be/open-keuken-met-sandra-bekkari/recept/roodbaars-uit-de-oven-met-venkel-wortel-en-komijn', 'c13fae04-024e-11e7-8f5f-00163edf48dd.jpg'),
(38, 'Tagliatelle met scampiâ€™s en lichte currysaus', 'Gerecht', '15 - 30 min', '00 g tagliatelle\r\n\r\neen snuifje zout\r\n\r\n1 scheutje olijfolie\r\n\r\nvoor de scampi\r\n\r\neen scheutje arachideolie\r\n\r\n800 g Black Tiger scampiâ€™s\r\n\r\npeper\r\n\r\nzout\r\n\r\nvoor de groenten\r\n\r\n200 g babymaÃ¯s\r\n\r\n1 courgette\r\n\r\n150 g sluimererwten\r\n\r\nÂ½ witte selder\r\n\r\n200 g kerstomaatjes\r\n\r\nvoor de saus\r\n\r\n1 el arachideolie\r\n\r\n1 appel (Granny Smith)\r\n\r\n2 blokjes kippenbouillon\r\n\r\n1 sjalot\r\n\r\n2 el currypoeder\r\n\r\nÂ¼ banaan\r\n\r\n250 ml witte wijn\r\n\r\n100 ml plantaardige room\r\n\r\n2 kokosrotsjes (rocher)\r\n\r\npeper\r\n\r\nzout', 'Begin met de saus. Pel en snij een sjalot grof.\r\n\r\nSpoel en schil de bleke selder. \r\n\r\nDoe 1 eetlepel arachideolie in een pan en stoof de fijngesneden sjalot en de selderschillen aan. Hou de geschilde selderstengels opzij.\r\n\r\nSnij de appel in vier, verwijder het klokhuis en snij in stukjes. Doe bij de sjalot en stoof mee aan.\r\n\r\nNeem de kokosrotsjes, snij het in stukjes en doe het ook bij in de pot. Dit zorgt voor een volle exotische smaak.\r\n\r\nVoeg ook 2 verkruimelde kippenbouillonblokjes en een kwart van een banaan toe. \r\n\r\nBlus met een glas witte wijn en een flinke scheut water. \r\n\r\nVoeg daarna 2 eetlepels curry toe.  \r\n\r\nLaat 15 minuten pruttelen onder deksel. \r\n\r\nVoor de scampi: pel de scampiâ€™s en verwijder het darmkanaal. \r\n\r\nBak de scampiâ€™s in 2 eetlepels arachideolie. Laat de pan heel warm worden vooraleer je begint te bakken. Bak ze max 2 minuten langs elke kant. Kruid af met peper en zout.\r\n\r\nVoor de groenten: Snij de courgette (haal er de zaadlijsten uit) en de geschilde selder in hapklare stukjes. Halveer de babymaÃ¯s. Stoom al die groenten met de sluimererwten al dente. Reken 8 Ã  12 minuten vanaf het water kookt (afhankelijk van de grootte van de stukken).\r\n\r\nVoor de pasta: Kook de tagliatelle. Doe een scheut olijfolie en een snuifje zout bij het water in de kookpot.  \r\n\r\nGa verder met de saus. Mix de gestoofde groenten met een staafmixer en zeef daarna zodat de grove stukjes er uit zijn. Voeg er de room aan toe. Kruid af met peper en zout.\r\n\r\nSnij de tomaatjes in 2 en voeg samen met de gestoomde groentjes toe aan de saus. \r\n\r\nGiet de tagliatelle af en dresseer met de groenten, scampi en saus in een diep bord. Smakelijk.', 'tagliatscampi.jpg');

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `recept`
--
ALTER TABLE `recept`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `recept`
--
ALTER TABLE `recept`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
