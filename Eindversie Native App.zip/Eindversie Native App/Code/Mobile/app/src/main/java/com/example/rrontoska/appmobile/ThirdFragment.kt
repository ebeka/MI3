package com.example.rrontoska.appmobile

import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import kotlinx.android.synthetic.main.third_layout.*

class ThirdFragment : Fragment() {

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return LayoutInflater.from(container?.context).inflate(R.layout.third_layout, container, false)


/*
        btn_insert.setOnClickListener({
            if(etvTitel.text.toString().length > 0 &&
                    etvRecept.text.toString().length > 0){
                var user = User(etvTitel.text.toString(),etvRecept.text.toString())
                //var db = DataBaseHandler(ThirdFragment.this)
               // db.insertDate(user)
            }
        })
    */

    }
}
