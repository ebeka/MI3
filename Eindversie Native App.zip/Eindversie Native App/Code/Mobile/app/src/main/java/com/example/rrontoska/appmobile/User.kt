package com.example.rrontoska.appmobile

class User {


    var id : Int = 0
    var titel : String = ""
    var recept : String = ""

    constructor(titel:String,recept:String){
        this.titel = titel
        this.recept = recept
    }
}